// API service for communicating with the Flask backend

export async function predictCreditEligibility(formData: Record<string, any>) {
  try {
    // Transform form data to match the expected API format
    // The API expects features in a specific order
    const features = [
      formData.income,
      formData.age,
      formData.experience,
      formData.married,
      formData.house_ownership,
      formData.car_ownership,
      formData.profession,
      formData.city,
      formData.state,
      formData.current_job_years,
      formData.current_house_years,
    ]

    // Make the API call to the Flask backend
    const response = await fetch("http://localhost:5000/predict", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ features }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error || "Failed to get prediction")
    }

    const data = await response.json()

    // Return the raw prediction (0 or 1) from the API
    return {
      prediction: data.prediction,
      eligible: data.prediction === 1,
      // Generate a score for visualization purposes
      score: data.prediction === 1 ? 0.7 + Math.random() * 0.3 : Math.random() * 0.5,
    }
  } catch (error) {
    console.error("Error predicting credit eligibility:", error)
    throw error
  }
}

export async function checkApiHealth() {
  try {
    const response = await fetch("http://localhost:5000/health")
    return response.ok
  } catch (error) {
    console.error("API health check failed:", error)
    return false
  }
}
