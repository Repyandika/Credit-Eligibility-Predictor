// State mappings
export const stateMapping: Record<string, number> = {
  Andhra_Pradesh: 0,
  Assam: 1,
  Bihar: 2,
  Chandigarh: 3,
  Chhattisgarh: 4,
  Delhi: 5,
  Gujarat: 6,
  Haryana: 7,
  Himachal_Pradesh: 8,
  Jammu_and_Kashmir: 9,
  Jharkhand: 10,
  Karnataka: 11,
  Kerala: 12,
  Madhya_Pradesh: 13,
  Maharashtra: 14,
  Manipur: 15,
  Mizoram: 16,
  Odisha: 17,
  Puducherry: 18,
  Punjab: 19,
  Rajasthan: 20,
  Sikkim: 21,
  Tamil_Nadu: 22,
  Telangana: 23,
  Tripura: 24,
  Uttar_Pradesh: 25,
  "Uttar_Pradesh[5]": 26,
  Uttarakhand: 27,
  West_Bengal: 28,
}

// Profession mappings
export const professionMapping: Record<string, number> = {
  Air_traffic_controller: 0,
  Analyst: 1,
  Architect: 2,
  Army_officer: 3,
  Artist: 4,
  Aviator: 5,
  Biomedical_Engineer: 6,
  Chartered_Accountant: 7,
  Chef: 8,
  Chemical_engineer: 9,
  Civil_engineer: 10,
  Civil_servant: 11,
  Comedian: 12,
  Computer_hardware_engineer: 13,
  Computer_operator: 14,
  Consultant: 15,
  Dentist: 16,
  Design_Engineer: 17,
  Designer: 18,
  Drafter: 19,
  Economist: 20,
  Engineer: 21,
  Fashion_Designer: 22,
  Financial_Analyst: 23,
  Firefighter: 24,
  Flight_attendant: 25,
  Geologist: 26,
  Graphic_Designer: 27,
  Hotel_Manager: 28,
  Industrial_Engineer: 29,
  Lawyer: 30,
  Librarian: 31,
  Magistrate: 32,
  Mechanical_engineer: 33,
  Microbiologist: 34,
  Official: 35,
  Petroleum_Engineer: 36,
  Physician: 37,
  Police_officer: 38,
  Politician: 39,
  Psychologist: 40,
  Scientist: 41,
  Secretary: 42,
  Software_Developer: 43,
  Statistician: 44,
  Surgeon: 45,
  Surveyor: 46,
  Technical_writer: 47,
  Technician: 48,
  Technology_specialist: 49,
  Web_designer: 50,
}

// City mappings (showing first 100 for performance)
export const cityMapping: Record<string, number> = {
  Adoni: 0,
  Agartala: 1,
  Agra: 2,
  Ahmedabad: 3,
  Ahmednagar: 4,
  Aizawl: 5,
  Ajmer: 6,
  Akola: 7,
  Alappuzha: 8,
  Aligarh: 9,
  Allahabad: 10,
  Alwar: 11,
  Ambala: 12,
  Ambarnath: 13,
  Ambattur: 14,
  Amravati: 15,
  Amritsar: 16,
  Amroha: 17,
  Anand: 18,
  Anantapur: 19,
  Arrah: 20,
  Asansol: 21,
  Aurangabad: 22,
  Avadi: 23,
  Bahraich: 24,
  Bally: 25,
  Bangalore: 26,
  Baranagar: 27,
  Barasat: 28,
  Bardhaman: 29,
  Bareilly: 30,
  Bathinda: 31,
  Begusarai: 32,
  Belgaum: 33,
  Bellary: 34,
  Berhampore: 35,
  Berhampur: 36,
  Bettiah: 37,
  Bhagalpur: 38,
  "Bhalswa Jahangir Pur": 39,
  Bharatpur: 40,
  Bhatpara: 41,
  Bhavnagar: 42,
  Bhilai: 43,
  Bhilwara: 44,
  Bhimavaram: 45,
  Bhind: 46,
  Bhiwandi: 47,
  Bhiwani: 48,
  Bhopal: 49,
  Bhubaneswar: 50,
  Bhusawal: 51,
  Bidar: 52,
  Bidhannagar: 53,
  "Bihar Sharif": 54,
  Bikaner: 55,
  Bilaspur: 56,
  Bokaro: 57,
  Bulandshahr: 58,
  Burhanpur: 59,
  Buxar: 60,
  Chandigarh: 61,
  Chandrapur: 62,
  Chennai: 63,
  Chhapra: 64,
  Chinsurah: 65,
  Chittoor: 66,
  Coimbatore: 67,
  Cuttack: 68,
  Danapur: 69,
  Darbhanga: 70,
  Davanagere: 71,
  Dehradun: 72,
  Dehri: 73,
  Delhi: 74,
  Deoghar: 75,
  Dewas: 76,
  Dhanbad: 77,
  Dharmavaram: 78,
  Dhule: 79,
  Dibrugarh: 80,
  Dindigul: 81,
  Durg: 82,
  Durgapur: 83,
  Eluru: 84,
  Erode: 85,
  Etawah: 86,
  Faridabad: 87,
  Farrukhabad: 88,
  Fatehpur: 89,
  Firozabad: 90,
  Gandhidham: 91,
  Gandhinagar: 92,
  Gangtok: 93,
  Gaya: 94,
  Ghaziabad: 95,
  Gopalpur: 96,
  Gorakhpur: 97,
  Gudivada: 98,
  Gulbarga: 99,
}

// This is a simplified implementation of a Random Forest model
// In a real application, you would implement the actual model logic here
export function predictCreditEligibility(data: Record<string, any>): { score: number; eligible: boolean } {
  // This is a placeholder for the actual model implementation
  // In a real application, you would use the trained model to make predictions

  // For demonstration purposes, we'll use a simple scoring system
  let score = 0

  // Income factor (higher income = higher score)
  score += Math.min(data.income / 100000, 0.3)

  // Age factor (middle age gets highest score)
  const ageFactor = data.age >= 25 && data.age <= 50 ? 0.15 : 0.05
  score += ageFactor

  // Experience factor
  score += Math.min(data.experience / 20, 0.1)

  // Married factor
  score += data.married ? 0.05 : 0

  // House ownership
  score += data.house_ownership ? 0.1 : 0

  // Car ownership
  score += data.car_ownership ? 0.05 : 0

  // Job stability
  score += Math.min(data.current_job_years / 10, 0.15)

  // Housing stability
  score += Math.min(data.current_house_years / 10, 0.1)

  // Normalize score to be between 0 and 1
  score = Math.min(Math.max(score, 0), 1)

  // Determine eligibility (threshold at 0.5)
  const eligible = score >= 0.5

  return { score, eligible }
}
