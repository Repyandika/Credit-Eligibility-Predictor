import { CreditForm } from "@/components/credit-form"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 py-12">
      <div className="container mx-auto px-4">
        <header className="mb-8 text-center">
          <h1 className="mb-2 text-3xl font-bold text-gray-900">Credit Eligibility Prediction</h1>
          <p className="text-gray-600">Enter your information to check if you are eligible for credit</p>
        </header>

        <div className="mx-auto max-w-2xl rounded-lg bg-white p-6 shadow-lg">
          <CreditForm />
        </div>

        <footer className="mt-8 text-center text-sm text-gray-500">
          <p>© {new Date().getFullYear()} Credit Eligibility Predictor</p>
          <p className="mt-1">All predictions are processed by a Flask API using a Random Forest model</p>
        </footer>
      </div>
    </div>
  )
}
