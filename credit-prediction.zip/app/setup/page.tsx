import Link from "next/link"
import { ArrowLeft, CreditCard, Server } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function SetupPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <header className="border-b bg-white shadow-sm">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <CreditCard className="h-6 w-6 text-emerald-600" />
            <h1 className="text-xl font-semibold text-gray-900">Credit Eligibility Predictor</h1>
          </div>
          <nav>
            <ul className="flex gap-6">
              <li>
                <Link href="/" className="text-gray-600 hover:text-gray-900">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-600 hover:text-gray-900">
                  About
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/" className="flex items-center gap-1 text-emerald-600 hover:text-emerald-700">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Home</span>
          </Link>
        </div>

        <div className="mx-auto max-w-3xl rounded-lg bg-white p-8 shadow-lg">
          <div className="mb-6 flex items-center justify-center gap-2 text-emerald-600">
            <Server className="h-10 w-10" />
            <h2 className="text-2xl font-semibold">API Setup Instructions</h2>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="mb-2 text-lg font-medium text-gray-900">1. Install Required Python Packages</h3>
              <div className="rounded-md bg-gray-900 p-4 text-white">
                <pre className="overflow-x-auto">
                  <code>pip install flask flask-cors pandas scikit-learn joblib</code>
                </pre>
              </div>
            </div>

            <div>
              <h3 className="mb-2 text-lg font-medium text-gray-900">2. Save Your Flask API Code</h3>
              <p className="mb-2 text-gray-600">
                Save the following code to a file named <code className="rounded bg-gray-100 px-1 py-0.5">app.py</code>:
              </p>
              <div className="rounded-md bg-gray-900 p-4 text-white">
                <pre className="overflow-x-auto">
                  <code>
                    {`from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import pandas as pd
import os

app = Flask(__name__)
CORS(app)

model_path = os.path.join(os.path.dirname(__file__), "model/random_forest_model.pkl")
model = joblib.load(model_path)

# Urutan kolom sesuai saat training model
FEATURE_COLUMNS = [
    "income",
    "age",
    "experience",
    "married",
    "house_ownership",
    "car_ownership",
    "profession",
    "city",
    "state",
    "current_job_years",
    "current_house_years"
]

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    if 'features' not in data:
        return jsonify({'error': 'Missing "features" in request.'}), 400

    features = data['features']

    if len(features) != len(FEATURE_COLUMNS):
        return jsonify({'error': f'Expected {len(FEATURE_COLUMNS)} features, got {len(features)}.'}), 400

    df = pd.DataFrame([features], columns=FEATURE_COLUMNS)
    prediction = model.predict(df)

    return jsonify({'prediction': int(prediction[0])})

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy'})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)`}
                  </code>
                </pre>
              </div>
            </div>

            <div>
              <h3 className="mb-2 text-lg font-medium text-gray-900">3. Create a Directory for Your Model</h3>
              <div className="rounded-md bg-gray-900 p-4 text-white">
                <pre className="overflow-x-auto">
                  <code>mkdir -p model</code>
                </pre>
              </div>
              <p className="mt-2 text-gray-600">
                Place your <code className="rounded bg-gray-100 px-1 py-0.5">random_forest_model.pkl</code> file in the
                model directory.
              </p>
            </div>

            <div>
              <h3 className="mb-2 text-lg font-medium text-gray-900">4. Run the Flask API Server</h3>
              <div className="rounded-md bg-gray-900 p-4 text-white">
                <pre className="overflow-x-auto">
                  <code>python app.py</code>
                </pre>
              </div>
              <p className="mt-2 text-gray-600">
                The API server will start running at{" "}
                <code className="rounded bg-gray-100 px-1 py-0.5">http://localhost:5000</code>
              </p>
            </div>

            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-amber-800">
              <h3 className="mb-2 font-medium">Important Note:</h3>
              <p>
                Make sure the Flask API server is running before using the credit prediction feature. The web
                application needs to communicate with the API to make predictions using your Random Forest model.
              </p>
            </div>

            <div className="flex justify-center">
              <Button asChild className="bg-emerald-600 px-6 py-2 hover:bg-emerald-700">
                <Link href="/">Return to Home</Link>
              </Button>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t bg-white py-6">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} Credit Eligibility Predictor. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
