import Link from "next/link"
import { ArrowLeft, CreditCard, Shield } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <header className="border-b bg-white shadow-sm">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <CreditCard className="h-6 w-6 text-emerald-600" />
            <h1 className="text-xl font-semibold text-gray-900">Credit Eligibility Predictor</h1>
          </div>
          <nav>
            <ul className="flex gap-6">
              <li>
                <Link href="/" className="text-gray-600 hover:text-gray-900">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-emerald-600 hover:text-emerald-700">
                  About
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/" className="flex items-center gap-1 text-emerald-600 hover:text-emerald-700">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Home</span>
          </Link>
        </div>

        <div className="mx-auto max-w-3xl rounded-lg bg-white p-8 shadow-lg">
          <h2 className="mb-6 text-center text-3xl font-bold text-gray-900">About Our Prediction Model</h2>

          <div className="mb-8">
            <h3 className="mb-3 text-xl font-semibold text-gray-800">How It Works</h3>
            <p className="text-gray-600">
              Our credit eligibility prediction system uses a Random Forest machine learning algorithm to analyze
              various personal and financial factors to determine credit eligibility. The model has been trained on
              historical data to identify patterns that correlate with credit risk.
            </p>
          </div>

          <div className="mb-8">
            <h3 className="mb-3 text-xl font-semibold text-gray-800">Variables Considered</h3>
            <p className="mb-4 text-gray-600">The model takes into account the following factors:</p>
            <ul className="grid grid-cols-1 gap-2 md:grid-cols-2">
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">Income</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">Age</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">Experience</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">Marital Status</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">House Ownership</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">Car Ownership</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">Profession</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">City</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">State</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">Years at Current Job</li>
              <li className="rounded-md bg-gray-50 p-2 text-gray-700">Years at Current Residence</li>
            </ul>
          </div>

          <div className="mb-8">
            <h3 className="mb-3 text-xl font-semibold text-gray-800">Random Forest Algorithm</h3>
            <p className="text-gray-600">
              Random Forest is an ensemble learning method that operates by constructing multiple decision trees during
              training. The output of the Random Forest is the class selected by most trees. This approach provides high
              accuracy and helps prevent overfitting, making it ideal for credit risk assessment.
            </p>
          </div>

          <div className="flex items-center justify-center gap-2 rounded-lg border border-emerald-100 bg-emerald-50 p-4 text-emerald-700">
            <Shield className="h-5 w-5" />
            <p>All predictions are made locally in your browser. Your data never leaves your device.</p>
          </div>
        </div>
      </main>

      <footer className="border-t bg-white py-6">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} Credit Eligibility Predictor. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
