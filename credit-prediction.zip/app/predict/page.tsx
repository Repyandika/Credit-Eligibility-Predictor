"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, CreditCard } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PredictionForm } from "@/components/prediction-form"
import { PredictionResult } from "@/components/prediction-result"
import { predictCreditEligibility, checkApiHealth } from "@/lib/api"
// Import the PredictionAlert component
import { PredictionAlert } from "@/components/prediction-alert"

export default function PredictPage() {
  const [predictionResult, setPredictionResult] = useState<{
    score: number
    eligible: boolean
    prediction?: number
  } | null>(null)

  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Add state for alert
  const [showAlert, setShowAlert] = useState(false)
  const [alertPrediction, setAlertPrediction] = useState<number | null>(null)

  // Update the handlePrediction function to show the alert
  const handlePrediction = async (formData: Record<string, any>) => {
    setIsLoading(true)
    setError(null)

    try {
      // First check if the API is available
      const isHealthy = await checkApiHealth()

      if (!isHealthy) {
        throw new Error("API server is not available. Please make sure the Flask server is running.")
      }

      // Process the form data to match the expected format
      const processedData = {
        ...formData,
        married: Number(formData.married),
        house_ownership: Number(formData.house_ownership),
        car_ownership: Number(formData.car_ownership),
        profession: Number(formData.profession),
        city: Number(formData.city),
        state: Number(formData.state),
      }

      // Call the API
      const result = await predictCreditEligibility(processedData)

      // Set the prediction result from the API response
      setPredictionResult({
        score: result.score,
        eligible: result.eligible,
        prediction: result.prediction,
      })

      // Show the alert with the prediction result
      setAlertPrediction(result.prediction)
      setShowAlert(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const handleReset = () => {
    setPredictionResult(null)
  }

  // Add the alert component to the JSX
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {showAlert && alertPrediction !== null && (
        <PredictionAlert prediction={alertPrediction} onClose={() => setShowAlert(false)} />
      )}

      <header className="border-b bg-white shadow-sm">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <CreditCard className="h-6 w-6 text-emerald-600" />
            <h1 className="text-xl font-semibold text-gray-900">Credit Eligibility Predictor</h1>
          </div>
          <nav>
            <ul className="flex gap-6">
              <li>
                <Link href="/" className="text-gray-600 hover:text-gray-900">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-600 hover:text-gray-900">
                  About
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/" className="flex items-center gap-1 text-emerald-600 hover:text-emerald-700">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Home</span>
          </Link>
        </div>

        <Card className="mx-auto max-w-4xl">
          <CardHeader>
            <CardTitle className="text-center text-2xl">Credit Eligibility Prediction</CardTitle>
            <CardDescription className="text-center">
              {predictionResult
                ? "Review your credit eligibility result"
                : "Fill in your details to check your credit eligibility"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {predictionResult ? (
              <PredictionResult result={predictionResult} onReset={handleReset} />
            ) : (
              <PredictionForm onSubmit={handlePrediction} isLoading={isLoading} />
            )}
          </CardContent>
        </Card>
        {error && (
          <div className="mx-auto mt-4 max-w-4xl rounded-lg border border-red-200 bg-red-50 p-4 text-red-800">
            <p className="font-medium">Error:</p>
            <p>{error}</p>
            <p className="mt-2 text-sm">Please make sure the Flask API server is running at http://localhost:5000</p>
          </div>
        )}
      </main>

      <footer className="border-t bg-white py-6">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} Credit Eligibility Predictor. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
