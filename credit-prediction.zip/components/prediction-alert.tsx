"use client"

import { useState, useEffect } from "react"
import { CheckCircle2, XCircle, X } from "lucide-react"

type PredictionAlertProps = {
  prediction: number
  onClose: () => void
}

export function PredictionAlert({ prediction, onClose }: PredictionAlertProps) {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    // Auto-close the alert after 5 seconds
    const timer = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onClose, 300) // Allow time for fade-out animation
    }, 5000)

    return () => clearTimeout(timer)
  }, [onClose])

  if (!isVisible) return null

  return (
    <div
      className={`fixed left-1/2 top-4 z-50 flex w-full max-w-md -translate-x-1/2 transform items-center justify-between rounded-lg p-4 shadow-lg transition-opacity duration-300 ${
        isVisible ? "opacity-100" : "opacity-0"
      } ${
        prediction === 1
          ? "border border-emerald-200 bg-emerald-50 text-emerald-800"
          : "border border-red-200 bg-red-50 text-red-800"
      }`}
    >
      <div className="flex items-center gap-3">
        {prediction === 1 ? (
          <CheckCircle2 className="h-6 w-6 text-emerald-500" />
        ) : (
          <XCircle className="h-6 w-6 text-red-500" />
        )}
        <div>
          <p className="font-medium">Prediction Result</p>
          <p className="text-lg font-bold">{prediction === 1 ? "Eligible" : "Not Eligible"}</p>
        </div>
      </div>
      <button
        onClick={() => {
          setIsVisible(false)
          setTimeout(onClose, 300)
        }}
        className="rounded-full p-1 hover:bg-gray-200"
      >
        <X className="h-5 w-5" />
      </button>
    </div>
  )
}
