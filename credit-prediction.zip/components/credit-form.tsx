"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle2, XCircle, AlertCircle } from "lucide-react"

// Define the form schema with validation
const formSchema = z.object({
  income: z.coerce.number().positive("Income must be a positive number"),
  age: z.coerce.number().int().positive("Age must be a positive integer"),
  experience: z.coerce.number().int().min(0, "Experience cannot be negative"),
  married: z.coerce.number().int().min(0).max(1, "Married must be 0 or 1"),
  house_ownership: z.coerce.number().int().min(0, "House ownership must be a valid code"),
  car_ownership: z.coerce.number().int().min(0).max(1, "Car ownership must be 0 or 1"),
  profession: z.coerce.number().int().min(0, "Profession must be a valid code"),
  city: z.coerce.number().int().min(0, "City must be a valid code"),
  state: z.coerce.number().int().min(0, "State must be a valid code"),
  current_job_years: z.coerce.number().int().min(0, "Years cannot be negative"),
  current_house_years: z.coerce.number().int().min(0, "Years cannot be negative"),
})

type FormValues = z.infer<typeof formSchema>

export function CreditForm() {
  const [prediction, setPrediction] = useState<number | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Initialize the form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      income: 0,
      age: 0,
      experience: 0,
      married: 0,
      house_ownership: 0,
      car_ownership: 0,
      profession: 0,
      city: 0,
      state: 0,
      current_job_years: 0,
      current_house_years: 0,
    },
  })

  // Handle form submission
  async function onSubmit(data: FormValues) {
    setIsLoading(true)
    setError(null)
    setPrediction(null)

    try {
      // Convert form data to features array in the correct order
      const features = [
        data.income,
        data.age,
        data.experience,
        data.married,
        data.house_ownership,
        data.car_ownership,
        data.profession,
        data.city,
        data.state,
        data.current_job_years,
        data.current_house_years,
      ]

      // Send data to Flask API
      const response = await fetch("http://localhost:5000/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ features }),
      })

      // Handle API errors
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to get prediction from API")
      }

      // Process the response
      const result = await response.json()

      // Check if the response has the expected format
      if (typeof result.prediction !== "number") {
        throw new Error("Invalid response format from API")
      }

      // Set the prediction result
      setPrediction(result.prediction)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {/* Income */}
            <FormField
              control={form.control}
              name="income"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Income</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" {...field} />
                  </FormControl>
                  <FormDescription>Annual income in currency units</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Age */}
            <FormField
              control={form.control}
              name="age"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Age</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" {...field} />
                  </FormControl>
                  <FormDescription>Age in years</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Experience */}
            <FormField
              control={form.control}
              name="experience"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Experience</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" {...field} />
                  </FormControl>
                  <FormDescription>Work experience in years</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Married */}
            <FormField
              control={form.control}
              name="married"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Married</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" min="0" max="1" {...field} />
                  </FormControl>
                  <FormDescription>0 = Not married, 1 = Married</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* House Ownership */}
            <FormField
              control={form.control}
              name="house_ownership"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>House Ownership</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" min="0" {...field} />
                  </FormControl>
                  <FormDescription>Numeric code for house ownership</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Car Ownership */}
            <FormField
              control={form.control}
              name="car_ownership"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Car Ownership</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" min="0" max="1" {...field} />
                  </FormControl>
                  <FormDescription>0 = No car, 1 = Has car</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Profession */}
            <FormField
              control={form.control}
              name="profession"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Profession</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" min="0" {...field} />
                  </FormControl>
                  <FormDescription>Numeric code for profession</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* City */}
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" min="0" {...field} />
                  </FormControl>
                  <FormDescription>Numeric code for city</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* State */}
            <FormField
              control={form.control}
              name="state"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>State</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" min="0" {...field} />
                  </FormControl>
                  <FormDescription>Numeric code for state</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Current Job Years */}
            <FormField
              control={form.control}
              name="current_job_years"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Current Job Years</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" min="0" {...field} />
                  </FormControl>
                  <FormDescription>Years at current job</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Current House Years */}
            <FormField
              control={form.control}
              name="current_house_years"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Current House Years</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="0" min="0" {...field} />
                  </FormControl>
                  <FormDescription>Years at current residence</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              "Check Eligibility"
            )}
          </Button>
        </form>
      </Form>

      {/* Display prediction result */}
      {prediction !== null && (
        <Alert className={prediction === 1 ? "border-green-500 bg-green-50" : "border-red-500 bg-red-50"}>
          <div className="flex items-center gap-2">
            {prediction === 1 ? (
              <CheckCircle2 className="h-5 w-5 text-green-500" />
            ) : (
              <XCircle className="h-5 w-5 text-red-500" />
            )}
            <AlertTitle className="text-lg font-bold">
              {prediction === 1 ? "Eligible for Credit" : "Not Eligible for Credit"}
            </AlertTitle>
          </div>
          <AlertDescription className="mt-2">
            The prediction model returned: <span className="font-bold">{prediction}</span>
            <p className="mt-1 text-sm">
              {prediction === 1
                ? "Based on the provided information, you are likely to be approved for credit."
                : "Based on the provided information, you may not be approved for credit at this time."}
            </p>
          </AlertDescription>
        </Alert>
      )}

      {/* Display error message */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {error}
            <p className="mt-1 text-sm">Please make sure the Flask API server is running at http://localhost:5000</p>
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
