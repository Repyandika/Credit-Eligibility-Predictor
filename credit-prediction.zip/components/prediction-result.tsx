"use client"

import { CheckCircle2, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

type PredictionResultProps = {
  result: {
    score: number
    eligible: boolean
    prediction?: number
  }
  onReset: () => void
}

export function PredictionResult({ result, onReset }: PredictionResultProps) {
  const scorePercentage = Math.round(result.score * 100)

  return (
    <div className="space-y-6">
      <div className="rounded-lg border p-6 text-center">
        <div className="mb-4 flex justify-center">
          {result.eligible ? (
            <CheckCircle2 className="h-16 w-16 text-emerald-500" />
          ) : (
            <XCircle className="h-16 w-16 text-red-500" />
          )}
        </div>

        <h3 className="mb-2 text-2xl font-bold">
          {result.eligible ? "Eligible for Credit" : "Not Eligible for Credit"}
        </h3>

        <div className="mb-4 rounded-md bg-gray-100 p-3 text-center">
          <p className="text-lg font-medium">
            API Prediction Result: <span className="font-bold">{result.prediction}</span>(
            {result.eligible ? "Eligible" : "Not Eligible"})
          </p>
        </div>

        <p className="mb-6 text-gray-600">
          {result.eligible
            ? "Based on our Random Forest model analysis, you are likely to be approved for credit. The model has evaluated all your provided information and determined a favorable outcome."
            : "Based on our Random Forest model analysis, you may not be approved for credit at this time. The model has evaluated all your provided information and determined an unfavorable outcome."}
        </p>

        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm font-medium text-gray-700">Credit Score</span>
          <span className="text-sm font-medium text-gray-700">{scorePercentage}%</span>
        </div>

        <Progress
          value={scorePercentage}
          className={`h-3 ${
            scorePercentage >= 70 ? "bg-emerald-100" : scorePercentage >= 40 ? "bg-amber-100" : "bg-red-100"
          }`}
        />

        <div className="mt-2 grid grid-cols-3 text-xs">
          <div className="text-left text-red-500">Poor</div>
          <div className="text-center text-amber-500">Fair</div>
          <div className="text-right text-emerald-500">Excellent</div>
        </div>
      </div>

      {!result.eligible && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-amber-800">
          <h4 className="mb-2 font-semibold">Improvement Suggestions:</h4>
          <ul className="list-inside list-disc space-y-1">
            <li>Increase your income or reduce existing debt</li>
            <li>Build a longer employment history</li>
            <li>Improve your housing stability</li>
            <li>Consider applying for a secured credit card first</li>
          </ul>
        </div>
      )}

      <div className="flex justify-center">
        <Button
          onClick={onReset}
          variant="outline"
          className="border-emerald-200 text-emerald-700 hover:bg-emerald-50 hover:text-emerald-800"
        >
          Start New Assessment
        </Button>
      </div>
    </div>
  )
}
