"use client"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2 } from "lucide-react"
import { stateMapping, professionMapping, cityMapping } from "@/lib/mappings"

const formSchema = z.object({
  income: z.coerce.number().positive("Income must be a positive number"),
  age: z.coerce.number().int().positive("Age must be a positive integer"),
  experience: z.coerce.number().int().min(0, "Experience cannot be negative"),
  married: z.enum(["0", "1"], {
    required_error: "Please select marital status",
  }),
  house_ownership: z.enum(["0", "1"], {
    required_error: "Please select house ownership status",
  }),
  car_ownership: z.enum(["0", "1"], {
    required_error: "Please select car ownership status",
  }),
  profession: z.string({
    required_error: "Please select your profession",
  }),
  city: z.string({
    required_error: "Please select your city",
  }),
  state: z.string({
    required_error: "Please select your state",
  }),
  current_job_years: z.coerce.number().int().min(0, "Years cannot be negative"),
  current_house_years: z.coerce.number().int().min(0, "Years cannot be negative"),
})

type PredictionFormProps = {
  onSubmit: (values: Record<string, any>) => void
  isLoading: boolean
}

export function PredictionForm({ onSubmit, isLoading }: PredictionFormProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      income: 0,
      age: 0,
      experience: 0,
      married: "0",
      house_ownership: "0",
      car_ownership: "0",
      profession: "",
      city: "",
      state: "",
      current_job_years: 0,
      current_house_years: 0,
    },
  })

  function handleSubmit(values: z.infer<typeof formSchema>) {
    // Convert string values to numbers where needed
    const processedValues = {
      ...values,
      married: Number.parseInt(values.married),
      house_ownership: Number.parseInt(values.house_ownership),
      car_ownership: Number.parseInt(values.car_ownership),
    }

    onSubmit(processedValues)
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {/* Income */}
          <FormField
            control={form.control}
            name="income"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Income</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Annual income" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Age */}
          <FormField
            control={form.control}
            name="age"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Age</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Your age" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Experience */}
          <FormField
            control={form.control}
            name="experience"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Experience (years)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Years of experience" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Married */}
          <FormField
            control={form.control}
            name="married"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Marital Status</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select marital status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="0">Single</SelectItem>
                    <SelectItem value="1">Married</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* House Ownership */}
          <FormField
            control={form.control}
            name="house_ownership"
            render={({ field }) => (
              <FormItem>
                <FormLabel>House Ownership</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select ownership status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="0">No</SelectItem>
                    <SelectItem value="1">Yes</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Car Ownership */}
          <FormField
            control={form.control}
            name="car_ownership"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Car Ownership</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select ownership status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="0">No</SelectItem>
                    <SelectItem value="1">Yes</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Profession */}
          <FormField
            control={form.control}
            name="profession"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Profession</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select profession" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="max-h-[200px] overflow-y-auto">
                    {Object.entries(professionMapping).map(([profession, code]) => (
                      <SelectItem key={profession} value={code.toString()}>
                        {profession.replace(/_/g, " ")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* State */}
          <FormField
            control={form.control}
            name="state"
            render={({ field }) => (
              <FormItem>
                <FormLabel>State</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="max-h-[200px] overflow-y-auto">
                    {Object.entries(stateMapping).map(([state, code]) => (
                      <SelectItem key={state} value={code.toString()}>
                        {state.replace(/_/g, " ")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* City */}
          <FormField
            control={form.control}
            name="city"
            render={({ field }) => (
              <FormItem>
                <FormLabel>City</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select city" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="max-h-[200px] overflow-y-auto">
                    {Object.entries(cityMapping)
                      .slice(0, 100)
                      .map(([city, code]) => (
                        <SelectItem key={city} value={code.toString()}>
                          {city.replace(/\[\d+\]|\[\d+\]\[\d+\]/g, "")}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                <FormDescription>Showing top 100 cities for performance</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Current Job Years */}
          <FormField
            control={form.control}
            name="current_job_years"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Years at Current Job</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Years at current job" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Current House Years */}
          <FormField
            control={form.control}
            name="current_house_years"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Years at Current Residence</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Years at current residence" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            "Check Eligibility"
          )}
        </Button>
      </form>
    </Form>
  )
}
