"use client"

import { useEffect, useState } from "react"
import { AlertCircle, CheckCircle } from "lucide-react"
import { checkApiHealth } from "@/lib/api"

export function ApiStatus() {
  const [isApiAvailable, setIsApiAvailable] = useState<boolean | null>(null)
  const [isChecking, setIsChecking] = useState(true)

  useEffect(() => {
    const checkApi = async () => {
      setIsChecking(true)
      try {
        const isHealthy = await checkApiHealth()
        setIsApiAvailable(isHealthy)
      } catch (error) {
        setIsApiAvailable(false)
      } finally {
        setIsChecking(false)
      }
    }

    checkApi()

    // Check API health every 30 seconds
    const interval = setInterval(checkApi, 30000)

    return () => clearInterval(interval)
  }, [])

  if (isChecking && isApiAvailable === null) {
    return (
      <div className="flex items-center gap-2 rounded-md border border-gray-200 bg-gray-50 px-3 py-2 text-sm text-gray-600">
        <div className="h-2 w-2 animate-pulse rounded-full bg-gray-400"></div>
        Checking API connection...
      </div>
    )
  }

  if (isApiAvailable) {
    return (
      <div className="flex items-center gap-2 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
        <CheckCircle className="h-4 w-4" />
        API connected successfully
      </div>
    )
  }

  return (
    <div className="flex items-center gap-2 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
      <AlertCircle className="h-4 w-4" />
      API connection failed. Please make sure the Flask server is running.
    </div>
  )
}
